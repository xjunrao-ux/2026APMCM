"""Run from any directory with Python, NumPy, pandas, SciPy and matplotlib."""
import os
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
from itertools import product
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy.special import expit, softmax
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / "results"
DATA = ROOT / "题目与要求/date"
Q2 = ROOT / "11.27 问题二"
Q3 = ROOT / "problem3"
sys.path.insert(0, str(Q3))
from models import CALLS, COMBOS, CONTEXTS, design, combo_design, logistic, multinomial

SEED, BOOT = 20261127, 499
DIST = np.arange(5, 201)
SIZES = [3, 8, 15]
CONDITIONS = CONTEXTS + ["standardized"]
KEYS = ["CallType", "Context", "Npenguins", "Distance"]


def save(frame, name):
    frame.to_csv(OUT / (name + ".csv"), index=False, encoding="utf-8-sig", float_format="%.9g")


def acoustic():
    gam = pd.read_csv(Q2 / "results/gam_predictions.csv").query("hold == 0")
    weights = pd.read_csv(Q2 / "gam_baseline/results/weights_comparison.csv").set_index("metric").critic
    means, errors, curves = [], [], []
    knots = np.array([4, 8, 16, 32, 64, 128, 256])
    for ci, call in enumerate(CALLS[1:]):
        cols, se = [], []
        for mi, metric in enumerate(weights.index):
            a = pd.read_csv(next(DATA.glob(f"Data{3+ci+3*mi:02}_*.csv")))
            assert [int(c.strip("m")) for c in a] == list(knots)
            cols.append(a.mean().values)
            se.append(np.interp(np.log2(DIST), np.log2(knots), a.std(ddof=0)/np.sqrt(a.count())))
        means.append(np.column_stack(cols))
        errors.append(np.sqrt(np.sum((weights.values[:, None]*se)**2, axis=0)))
        g = gam[gam.call == call].pivot(index="d",columns="metric",values="estimate")
        full = g[weights.index] @ weights
        curves.append(full.loc[DIST].values)
        refs = pd.read_csv(Q2 / "gam_baseline/results/gam_effective_range.csv")
        for row in refs[(refs.call==call) & refs.weight.str.startswith("critic")].itertuples():
            assert abs(full.index[full < row.threshold][0] - row.D) <= .101
    x = np.vstack(means)
    x = (x-x.min(0))/np.ptp(x,axis=0)
    info = x.std(0)*(1-np.corrcoef(x.T)).sum(1)
    np.testing.assert_allclose(info/info.sum(),weights)
    return np.array(curves), np.array(errors)


def run():
    OUT.mkdir(exist_ok=True)
    d = pd.read_csv(next(DATA.glob("Data02*.csv")))
    pair = d.groupby("expID")
    assert (pd.crosstab(d.expID, d.Type)[["call","control"]] == 1).all().all()
    assert pair.Context.nunique().max() == 1
    natural = d[d.Type=="call"]
    np.testing.assert_equal(natural.Npenguins.quantile([.25,.5,.75]).values, SIZES)
    weights = natural.Context.value_counts(normalize=True).reindex(CONTEXTS).values
    code = d[["HeadsUpYesNo","VocalYesNo","ApproachYesNo"]].values @ [4,2,1]
    pos = code > 0
    assert np.array_equal(pos,d.ResponseYesNo)
    x,z = design(d),design(d,"full_interaction")
    grid = pd.DataFrame(product(CALLS, CONTEXTS, SIZES, DIST),columns=KEYS)
    gx,gz = combo_design(design(grid)), design(grid,"full_interaction")

    def predict(w):
        p = expit(gz @ logistic(z,pos,w))
        q = softmax(gx @ multinomial(x[pos],code[pos],w[pos],2.0),axis=1)
        pi = np.column_stack([1-p,p[:,None]*q])
        assert pi.min() >= 0 and np.allclose(pi.sum(1),1)
        raw = pi.reshape(len(CALLS),len(CONTEXTS),len(SIZES),len(DIST),8)
        avg = np.einsum("ckndj,k->cndj",raw,weights)
        return np.concatenate([raw,avg[:,None]],axis=1)

    pi = predict(np.ones(len(d)))
    full = pd.DataFrame(product(CALLS,CONDITIONS,SIZES,DIST),columns=KEYS)
    for j,combo in enumerate(COMBOS):
        full["p_"+combo] = pi[...,j].ravel()
    check = pd.read_csv(Q3 / "results/q3_behavior_combo_predictions.csv",dtype={"combo":str})
    ref = check.pivot(index=KEYS,columns="combo",values="p_all")
    aligned = full.set_index(KEYS).loc[ref.index,["p_"+s for s in ref.columns]]
    residual = np.max(np.abs(aligned.values-ref.values))
    assert residual < 1e-5, residual
    union = np.array([("A" in c or "V" in c) for c in COMBOS])
    ei = pi[...,union].sum(-1)
    for event in ("V","A","VA","H"):
        full["P_"+event] = pi[...,[all(b in c for b in event) for c in COMBOS]].sum(-1).ravel()
    np.testing.assert_allclose(full.P_V+full.P_A-full.P_VA,ei.ravel())
    full["EI"] = ei.ravel()
    save(full,"behavior")
    delta = ei[1:] - ei[0]
    samples = np.empty((BOOT,*delta.shape))
    ids,inv = np.unique(d.expID,return_inverse=True)
    rng = np.random.default_rng(SEED)
    for b in range(BOOT):
        w = np.bincount(rng.integers(len(ids),size=len(ids)),minlength=len(ids))[inv]
        pred = predict(w)[...,union].sum(-1)
        samples[b] = pred[1:]-pred[0]
    lo,hi = np.quantile(samples,[.025,.975],axis=0)
    sd = samples.std(0,ddof=1)
    critical = np.quantile(np.max(np.abs((samples-delta)/sd),axis=-1),.95,axis=0)
    band = delta-critical[...,None]*sd
    F,se = acoustic()
    rows, radii, scenarios, stability = [], [], [], []
    for i,call in enumerate(CALLS[1:]):
        for j,ctx in enumerate(CONDITIONS):
            contexts = CONTEXTS if ctx=="standardized" else [ctx]
            cells = d[d.CallType.isin([call,"control"]) & d.Context.isin(contexts)].groupby(["CallType","Context"])
            left,right = cells.Distance.min().max(),cells.Distance.max().min()
            for k,n in enumerate(SIZES):
                supported_n = bool((cells.Npenguins.min()<=n).all() and (cells.Npenguins.max()>=n).all())
                ix = i,j,k
                part = pd.DataFrame(dict(Distance=DIST,EI=ei[i+1,j,k],control=ei[0,j,k],delta=delta[ix],
                    lo95=lo[ix],hi95=hi[ix],sim_lower95=band[ix],F=F[i],F_SE=se[i],
                    within_cell_ranges=(DIST>=left)&(DIST<=right)&supported_n))
                part = part.assign(CallType=call,Context=ctx,Npenguins=n)
                rows.append(part)
                for loss,t in product([0,.05,.10,.15,.20],[.5,.6,.7]):
                    f = (1-loss)*F[i]
                    # Optional recognition-mediated scenario, anchored to observed-condition EI.
                    # A higher evaluation threshold alone leaves the response law unchanged.
                    ratio = expit(20*(f-.5))/expit(20*(F[i]-.5))
                    for dist in [50,100,150]:
                        h = dist-DIST[0]
                        scenarios.append((call,ctx,n,dist,t,loss,f[h],f[h]>=t,part.EI[h],part.delta[h],
                            part.control[h]+ratio[h]*part.delta[h],ratio[h]*part.delta[h],part.within_cell_ranges[h]))
                    for scope in ["pooled_distance","cell_ranges"]:
                        domain = np.ones(len(DIST),bool) if scope=="pooled_distance" else part.within_cell_ranges.values
                        grid = DIST[domain]
                        if len(grid):
                            # Resample the underlying positive-effect boundary, separate from
                            # the confidence-band decision rule reported as the main radius.
                            ok = (samples[:,i,j,k,:][:,domain]>0) & (f[domain]>=t)
                            length = np.cumprod(ok,axis=1).sum(1)
                            nonempty = length>0
                            quant = (np.quantile(grid[length[nonempty]-1],[.025,.5,.975])
                                     if nonempty.any() else [np.nan]*3)
                            stability.append((call,ctx,n,t,loss,scope,nonempty.mean(),*quant))
                        for shift in [-1,0,1]:
                            good_f = ((1-loss)*(F[i]+shift*se[i])>=t)[domain]
                            good_b = band[ix][domain]>0
                            bad = np.where(~(good_f & good_b))[0]
                            end = bad[0] if len(bad) else len(grid)
                            why = ("unsupported" if not len(grid) else "support_limit" if not len(bad)
                                   else "+".join(label for ok,label in [(good_f[end],"F"),(good_b[end],"behavior")] if not ok))
                            radii.append((call,ctx,n,t,loss,scope,shift,grid[0] if len(grid) else None,
                                grid[-1] if len(grid) else None,grid[end-1] if end else None,why))
    curves = pd.concat(rows)
    save(curves,"effects")
    radius = pd.DataFrame(radii,columns=["call","context","N","T","loss","scope","F_shift_SE","start_m","limit_m","radius_m","first_limit"])
    save(radius,"radius")
    save(pd.DataFrame(stability,columns=["call","context","N","T","loss","scope","fraction_nonempty",
        "positive_radius_q025","positive_radius_q50","positive_radius_q975"]),"bootstrap_radius")
    save(pd.DataFrame(scenarios,columns=["call","context","N","distance","T","loss","F_scenario","passes_T","EI_distance_model",
        "delta_distance_model","EI_recognition_scenario","delta_recognition_scenario","within_cell_ranges"]),"environment")
    counts = full[full.Distance.isin([50,100,150])].copy()
    estimates=[]
    for label,rho in [("one_participant",1/counts.Npenguins),("half_on_average",.5),("all",1.)]:
        estimates.append(counts[KEYS].assign(scenario=label,rho=rho,
            expected_vocal=counts.Npenguins*rho*counts.P_V,expected_approach=counts.Npenguins*rho*counts.P_A))
    save(pd.concat(estimates),"participant_scenarios")
    # Recover the target event in held-out trials using Q3's nested-CV folds and structures.
    oof = pd.read_csv(Q3/"results/grouped_oof.csv")
    oof = d[["expID","Type"]].merge(oof,on=["expID","Type"],validate="one_to_one")
    assert oof.groupby("expID").fold.nunique().max()==1
    cv = np.empty(len(d))
    for _,block in oof.groupby("fold"):
        test = oof.index.isin(block.index)
        train = ~test
        zfold = design(d,block.overall_structure.unique().item())
        gate = logistic(zfold[train],pos[train],np.ones(train.sum()))
        m = train & pos
        cl = multinomial(x[m],code[m],np.ones(m.sum()),2.0)
        cv[test] = expit(zfold[test]@gate)*softmax(combo_design(x[test])@cl,axis=1)[:,union[1:]].sum(1)
    observed = union[code]
    save(d[["expID","Type","CallType","Context"]].assign(fold=oof.fold,observed_EI=observed.astype(int),
        predicted_EI=cv,squared_error=(cv-observed)**2),"held_out_EI")
    calibration = pd.DataFrame(dict(predicted=cv,observed=observed))
    save(calibration.groupby(pd.qcut(cv,5,labels=False)).agg(n=("observed","size"),
        observed=("observed","mean"),predicted=("predicted","mean")).reset_index(names="bin"),"calibration")
    grp=curves.query("Context=='standardized' and Npenguins==8")
    fig,axes=plt.subplots(1,3,figsize=(12,3.8),sharey=True,layout="constrained")
    for ax,(call,g) in zip(axes,grp.groupby("CallType",sort=False)):
        ax.fill_between(g.Distance,g.sim_lower95,np.minimum(1,2*g.delta-g.sim_lower95),alpha=.17,color="#226d79")
        ax.plot(g.Distance,g.delta,color="#226d79",label="Net response")
        ax.plot(g.Distance,g.F,color="#ab5828",label="Fidelity")
        ax.axhline(0,color="gray",lw=.8)
        ax.axhline(.5,color="#ab5828",lw=.8,ls=":")
        ax.set(title=call,xlabel="Playback distance (m)")
    axes[0].set_ylabel("Probability difference / fidelity")
    axes[-1].legend(frameon=False)
    fig.savefig(OUT/"joint_curves.png",dpi=190)
    print("Q3 maximum probability discrepancy:",residual)
    print(radius.query("context=='standardized' and N==8 and loss==0 and F_shift_SE==0").to_string(index=False))
    print(grp.query("Distance==100").to_string(index=False))
    print("pair mismatches:",(pair[['Distance','Npenguins','Context']].nunique()>1).sum().to_dict())

if __name__=="__main__":
    run()
